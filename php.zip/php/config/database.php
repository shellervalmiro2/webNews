<?php
define("DB_HOST", "sql101.infinityfree.com");
define("DB_USER", "if0_39722397");
define("DB_PASS", "pehBevo9Zxfx");
define("DB_NAME", "if0_39722397_zvelake");
define("DB_ENC", "utf8mb3");
?>